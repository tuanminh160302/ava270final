package proj4;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 * CSC 120 - Project 4 - Steve Nguyen
 * I affirm that I have carried out the attached academic endeavors with full academic honesty.
 */
public class Main {

    /**
     * Create a 5-card-card-list
     * @param deck A deck of cards
     * @return A 5-card-card-list
     */
    public static ArrayList<Card> getCommunityCardList(Deck deck) {
        ArrayList<Card> cardList = new ArrayList<>();
        for (int i = 0; i < 5; i ++) {
            cardList.add(deck.deal());
        }
        return cardList;
    }

    /**
     * Create a 2-card-card-list
     * @param deck A deck of cards
     * @return A 5-card-card-list
     */
    public static ArrayList<Card> getStudCardList(Deck deck) {
        ArrayList<Card> cardList = new ArrayList<>();
        for (int i = 0; i < 2; i ++) {
            cardList.add(deck.deal());
        }
        return cardList;
    }

    /**
     * Deal 5 community cards
     * @param cardList A 5-card-card-list
     * @return A poker hand
     */
    public static CommunityCardSet getCommunityCards(ArrayList<Card> cardList) {
        CommunityCardSet community = new CommunityCardSet(cardList);
        return community;
    }

    /**
     * Create a hand from a 2-card-card-list
     * @param cardList A 2-card-card-list
     * @return A poker hand
     */
    public static StudPokerHand dealHand(CommunityCardSet community, ArrayList<Card> cardList) {
        StudPokerHand hand = new StudPokerHand(community, cardList);
        return hand;
    }

    /**
     * Prompt user for the answer
     * @return The user answer
     */
    public static int promptUser() {
        ArrayList<Integer> validAnswer = new ArrayList<>(Arrays.asList(1, 0, -1));
        Scanner reader = new Scanner(System.in);
        System.out.println("Enter your answer");
        int userAnswer = reader.nextInt();
        while (!validAnswer.contains(userAnswer)) {
            userAnswer = reader.nextInt();
        }
        return userAnswer;
    }

    /**
     * Play a round of poker game
     * @param deck The deck of cards
     * @return True if the player won the round. Otherwise, return false
     */
    public static boolean playRounds(Deck deck) {
        boolean roundWon = false;
        ArrayList<Card> communityCardList = getCommunityCardList(deck);
        CommunityCardSet communityCards = getCommunityCards(communityCardList);
        ArrayList<Card> cardList1 = getStudCardList(deck);
        ArrayList<Card> cardList2 = getStudCardList(deck);
        StudPokerHand hand1 = dealHand(communityCards, cardList1);
        StudPokerHand hand2 = dealHand(communityCards, cardList2);
        System.out.println(communityCards);
        System.out.println("Hand 1:");
        System.out.println(hand1);
        System.out.println("Hand 2:");
        System.out.println(hand2);
        int userAns = promptUser();
        int correctAns = hand1.compareTo(hand2);
        if (userAns == correctAns) {
            roundWon = true;
        } else if (userAns != correctAns) {
            roundWon = false;
        }
        return roundWon;
    }

    public static void main(String[] args) {
        Deck deck = new Deck();
        deck.shuffle();

        int score = 0;

        System.out.println("Game starts now!");
        boolean roundResult = true;
        while (roundResult) {
            if (!deck.enough()) {
                deck.gather();
                System.out.println("Not enough cards left to play!");
                System.out.println(String.format("Your total score is: %d", score));
                break;
            } else if (deck.enough()) {
                roundResult = playRounds(deck);
                if (roundResult) {
                    score += 1;
                    System.out.println("Correct answer!");
                    System.out.println(String.format("Your total score is: %d \n", score));
                } else if (!roundResult) {
                    System.out.println("Wrong answer!");
                    System.out.println(String.format("Your total score is: %d", score));
                }
            }
        }
    }
}
package proj4;

import java.sql.Array;
import java.util.ArrayList;

public class StudPokerHand {
    private ArrayList<Card> studHand = new ArrayList<>();;
    private ArrayList<Card> communitySet = new ArrayList<>();;
    private ArrayList<Card> studCardList;

    /**
     * Construct a stud poker hand
     * @param cardList The list of 2 cards that will be used to create a stud hand
     */
    public StudPokerHand(CommunityCardSet cc, ArrayList<Card> cardList) {
        this.studCardList = cardList;
        getCommunitySet(cc);
        ArrayList<Card> cardListCopied = cardList;
        for (int i = 0; i < cardListCopied.size(); i ++) {
            if (studHand.size() < cardListCopied.size()) {
                this.addCard(cardListCopied.get(i));
            }
        }
    }

    /**
     * Add a card to the hand
     * @param card The card that will be added to the hand
     */
    public void addCard(Card card) {
        studHand.add(card);
    }

    /**
     * Get the card at the indicated index
     * @param index The indicated index of the needed card
     * @return The card at the indicated index
     */
    public Card getIthCard(int index) {
        return studHand.get(index);
    }

    /**
     * Turn a community card set object into an arraylist of community cards
     * @param cc The community card set object
     */
    private void getCommunitySet(CommunityCardSet cc) {
        for (int i = 0; i < 5; i++) {
            this.communitySet.add(cc.getIthCard(i));
        }
    }

    /**
     * Get all combinations of all possible 5-card-hand out of total 7 cards
     * @return An arraylist contains all the possible hands
     */
    private ArrayList<PokerHand> getAllFiveCardHands() {
        ArrayList<PokerHand> hands = new ArrayList<>();
        hands.add(new PokerHand(this.communitySet));
        for (int i = 0; i < 5; i ++) {
            ArrayList<Card> cardList = this.communitySet;
            Card tempCard = cardList.get(i);
            cardList.remove(i);
            for (int k = 0; k < 2; k ++) {
                cardList.add(this.studCardList.get(k));
                hands.add(new PokerHand(cardList));
                cardList.remove(this.studCardList.get(k));
            }
            cardList.add(i, tempCard);
        }

        for (int i = 0; i < 4; i++) {
            Integer nextIndex = i + 1;
            ArrayList<Card> cardList = this.communitySet;
            Card tempCard1 = cardList.get(i);
            cardList.remove(i);
            while (nextIndex < 5) {
                Card tempCard2 = cardList.get(nextIndex-1);
                cardList.remove(nextIndex-1);
                cardList.add(this.studCardList.get(0));
                cardList.add(this.studCardList.get(1));
                hands.add(new PokerHand(cardList));
                cardList.remove(this.studCardList.get(0));
                cardList.remove(this.studCardList.get(1));
                cardList.add(nextIndex-1, tempCard2);
                nextIndex += 1;
            }
            cardList.add(i, tempCard1);
        }

        return hands;
    }

    /**
     * Get the best 5-card-hand out of all the hands
     * @return The best 5-card-hand
     */
    private PokerHand getBestFiveCardHand()
    {
        ArrayList<PokerHand> hands = getAllFiveCardHands();
        PokerHand bestSoFar = hands.get(0);

        for (int i = 1; i < hands.size(); i++) {
            if (hands.get(i).compareTo(bestSoFar) > 0) {
                bestSoFar = hands.get(i);
            }
        }
        return bestSoFar;
    }

    /**
     * Determines how this hand compares to another hand, using the
     * community card set to determine the best 5-card hand it can
     * make. Returns positive, negative, or zero depending on the comparison.
     *
     * @param other The hand to compare this hand to
     * @return a negative number if this is worth LESS than other, zero
     * if they are worth the SAME, and a positive number if this is worth
     * MORE than other
     */
    public int compareTo(StudPokerHand other) {
        PokerHand thisBest = getBestFiveCardHand();
        PokerHand otherBest = other.getBestFiveCardHand();
        return thisBest.compareTo(otherBest);
    }

    /**
     * Check if this stud set equals to other stud set
     * @param other Other stud set
     * @return true if they are equal, else false
     */
    public boolean equals(Object other){
        if (other == null){
            return false;
        }
        else if (other == this){
            return true;
        }
        else if (!(other instanceof PokerHand)){
            return false;
        }
        return this.studCardList == ((StudPokerHand) other).studCardList;
    }

    /**
     * Print out all the cards in the stud hand
     * @return The string of all the cards in the stud hand
     */
    public String toString(){
        String results = studCardList.get(0).toString() + ", " + studCardList.get(1).toString();
        return results;
    }
}

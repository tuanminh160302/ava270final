package proj4;

public class CardTests {

    /**
     * Create a test case to test create card with string params
     * @param msg The message describes the test case
     * @param rank The rank of the card (string)
     * @param suit  The suit of the card (string)
     * @param expected The expected result
     */
    public static void testCreateCardString(String msg, String rank, String suit, String expected) {
        Card card = new Card(rank, suit);
        Testing ts = new Testing();
        ts.setVerbose(true);
        ts.assertEquals(msg, expected, card.toString());
    }

    /**
     * Create a test case to test create card with integer params
     * @param msg The message describes the test case
     * @param rank The rank of the card (int)
     * @param suit  The suit of the card (int)
     * @param expected The expected result
     */
    public static void testCreateCardInt(String msg, int rank, int suit, String expected) {
        Card card = new Card(rank, suit);
        Testing ts = new Testing();
        ts.setVerbose(true);
        ts.assertEquals(msg, expected, card.toString());
    }

    /**
     * Create a test case to test get rank method of Card class
     * @param msg The message describes the test case
     * @param rank The rank of the card(string)
     * @param suit The suit of the card(string)
     * @param expected The expected result
     */
    public static void testGetRank(String msg, String rank, String suit, int expected) {
        Card card = new Card(rank, suit);
        Testing ts = new Testing();
        ts.setVerbose(true);
        ts.assertEquals(msg, expected, card.getRank());
    }

    /**
     * Create a test case to test get suit method of Card class
     * @param msg The message describes the test case
     * @param rank The rank of the card(string)
     * @param suit The suit of the card(string)
     * @param expected The expected result
     */
    public static void testGetSuit(String msg, String rank, String suit, String expected) {
        Card card = new Card(rank, suit);
        Testing ts = new Testing();
        ts.setVerbose(true);
        ts.assertEquals(msg, expected, card.getSuit());
    }

    public static void main(String[] args) {
        Testing ts = new Testing();
        ts.startTests();
        testCreateCardString("Create King of Clubs (facecard) using string params", "King", "Clubs"
        , "King of Clubs");
        testCreateCardString("Create 10 of Spades using string params", "10", "Spades"
                , "10 of Spades");
        testCreateCardString("Create Ten of Diamonds using string params", "Ten", "Diamonds"
                , "10 of Diamonds");
        testCreateCardInt("Create 9 of Diamonds using int params", 9, 3
                , "9 of Diamonds");
        testCreateCardInt("Create King of Clubs (facecard) using int params", 13, 2
                , "King of Clubs");
        testGetRank("Get rank of 9 of Diamonds", "9", "Diamonds", 9);
        testGetRank("Get rank of King of Hearts", "King", "Hearts", 13);
        testGetSuit("Get suit of 4 of Spades", "4", "Spades", "Spades");
        ts.finishTests();
    }
}

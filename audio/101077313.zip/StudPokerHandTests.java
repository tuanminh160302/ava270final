package proj4;

import java.util.ArrayList;

public class StudPokerHandTests {

    /**
     * Get the rank of the string version of a card
     * @param card The string version of a card
     * @return The string version of the rank
     */
    public static String convertRankStr(String card) {
        String rankStr = card.substring(0, card.length() - 1);
        if (rankStr.equals("J")) {
            rankStr = "11";
        } else if (rankStr.equals("Q")) {
            rankStr = "12";
        } else if (rankStr.equals("K")) {
            rankStr = "13";
        } else if (rankStr.equals("A")) {
            rankStr = "14";
        }
        return rankStr;
    }

    /**
     * Get the suit of the string version of a card
     * @param card The string version of a card
     * @return The string version of the suit
     */
    public static String convertSuitStr(String card) {
        String suit = card.substring(card.length() - 1);
        if (suit.equals("S")) {
            suit = "Spades";
        } else if (suit.equals("H")) {
            suit = "Hearts";
        } else if (suit.equals("D")) {
            suit = "Diamonds";
        } else if (suit.equals("C")) {
            suit = "Clubs";
        }
        return suit;
    }

    /**
     * Create a community card set object from the string version of the community card set
     * @param communityCardListStr the string version of the community card set
     * @return The community card set object
     */
    public static CommunityCardSet createCommunityCardSet(String communityCardListStr) {
        ArrayList<Card> communityCardList = new ArrayList<>();
        String[] cards = communityCardListStr.split(" ");
        for (int i = 0; i < 5; i ++) {
            String card = cards[i];
            String rankStr = convertRankStr(card);
            String suit = convertSuitStr(card);

            Card c = new Card(rankStr, suit);
            communityCardList.add(c);
        }

        return new CommunityCardSet(communityCardList);
    }

    /**
     * Create a 2-card-stud-set
     * @param studCardListStr The string version of the list
     * @return An arraylist contains 2 cards
     */
    public static ArrayList<Card> createStudCardList(String studCardListStr) {
        ArrayList<Card> studCardList = new ArrayList<>();
        String[] cards = studCardListStr.split(" ");
        for (int i = 0; i < 2; i ++) {
            String card = cards[i];
            String rankStr = convertRankStr(card);
            String suit = convertSuitStr(card);

            Card c = new Card(rankStr, suit);
            studCardList.add(c);
        }

        return studCardList;
    }

    /**
     * Create a stud poker hand from a string represent a card list
     * @param communityCardListStr The string represent a card list
     * @return A stud poker hand
     */
    public static StudPokerHand createStudHand(String communityCardListStr, String studCardListStr) {
        CommunityCardSet communityCards = createCommunityCardSet(communityCardListStr);
        ArrayList<Card> studCardList = createStudCardList(studCardListStr);
        return new StudPokerHand(communityCards, studCardList);
    }

    /**
     * Create a test case to test stud poker hands comparisons
     * @param communityCardListStr The string version of the community card set
     * @param studCardListStr1 The string version of the stud card list 1
     * @param studCardListStr2 The string version of the stud card list 2
     * @param msg The message describes the test case
     * @param expected The expected result
     */
    public static void createTestCase(String communityCardListStr, String studCardListStr1, String studCardListStr2,
                                      String msg, int expected) {
        StudPokerHand studHand1 = createStudHand(communityCardListStr, studCardListStr1);
        StudPokerHand studHand2 = createStudHand(communityCardListStr, studCardListStr2);
        Testing ts = new Testing();
        ts.setVerbose(true);
        ts.assertEquals(msg, expected, studHand1.compareTo(studHand2));
    }

    /**
     * Create a test case to test stud poker hands comparisons
     * @param communityCardListStr1 The string version of the community card set 1
     * @param communityCardListStr1 The string version of the community card set 2
     * @param studCardListStr1 The string version of the stud card list 1
     * @param studCardListStr2 The string version of the stud card list 2
     * @param msg The message describes the test case
     * @param expected The expected result
     */
    public static void createTestCase(String communityCardListStr1, String communityCardListStr2,
                                      String studCardListStr1, String studCardListStr2, String msg, int expected) {
        StudPokerHand studHand1 = createStudHand(communityCardListStr1, studCardListStr1);
        StudPokerHand studHand2 = createStudHand(communityCardListStr2, studCardListStr2);
        Testing ts = new Testing();
        ts.setVerbose(true);
        ts.assertEquals(msg, expected, studHand1.compareTo(studHand2));
    }

    public static void main(String[] args) {

        Testing ts = new Testing();
        ts.startTests();
        createTestCase("AS 2D 7H KS QC", "9D 8H 4C AD QD",
                "7D KD", "KH 5C", "Stud test: hands use different community cards",
                1);
        createTestCase("AH 2D 3S AD 5C", "AS 9C", "3C 5D",
                "Stud test: Both hands use the same community cards", -1);
        createTestCase("AH 2D 10S 7D 8C", "7S 10C", "7C 7H",
                "Stud test: two pairs (10s and 7s) beats 4-of-a-kind (7s)", 1);
        createTestCase("KD 2D KS 7D 10S", "10C 4S", "KC KH",
                "Stud test: two pairs (Kings and 10s) loses to 4-of-a-kind (Kings)", -1);
        createTestCase("JS 8D 10S JS 9D", "AD AS", "QS 7S",
                "Stud test: hand with the better hole cards (2 Aces) loses to flush", -1);
        createTestCase("KS AH KD 3C 8D", "AD 4C", "KH 8S",
                "Stud test: two pairs (Aces and Kings) beats full house (Kings over 8s)", 1);
        createTestCase("JD AH JS 9C QD", "9D 2C", "JH QS",
                "Stud test: two pairs (Jacks and 9s) loses to full house (Jacks over Queens)", -1);
        createTestCase("9S 10D JH QH KC", "9D QC", "JC 10S",
                "Stud test: hole cards make different 2-pair hands", 1);
        createTestCase("10D AC 6S 9C 2C", "5C 4C", "7C 3C",
                "Stud test: two flushes -- different on 3rd highest card", -1);
        createTestCase("4D 10H 9C QC KD", "KC 9D", "9H KH",
                "Stud test: tie when all community cards gives best hand", 0);
        createTestCase("JS JD 5C JH 2D", "8H 3D", "4S 8S",
                "Stud test: tie hands with one pair", 0);
        createTestCase("9S 4D 5C 9H KH", "5D KD", "KS 5C",
                "Stud test: tie hands with 2 pairs", 0);
        createTestCase("9S 4H 5C 9H KH", "2H 7H", "7H 2H",
                "Stud test: tie hands with flush", 0);

        ts.finishTests();
    }
}

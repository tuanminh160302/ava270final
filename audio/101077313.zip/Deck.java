package proj4; // do not erase. Gradescope expects this.
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class Deck {

    private final ArrayList<Integer> rankList = new ArrayList<>(Arrays.asList(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14));
    private final ArrayList<Integer> suitList = new ArrayList<>(Arrays.asList(0, 1, 2, 3));
    private ArrayList<Card> deck = new ArrayList<>();
    private int numDealt = 0;

    /**
     * Construct a deck of cards
     */
    public Deck() {
        for (int r = 0; r < rankList.size(); r ++) {
            for (int s = 0; s < suitList.size(); s ++) {
                Card card = new Card(rankList.get(r), suitList.get(s));
                deck.add(card);
            }
        }
    }

    /**
     * Shuffle the deck of cards
     */
    public void shuffle() {
        for (int i = 0; i < 52; i ++) {
            int randomIndex = ThreadLocalRandom.current().nextInt(numDealt, 52);
            Card temp = deck.get(i);
            deck.set(i, deck.get(randomIndex));
            deck.set(randomIndex, temp);
        }
    }

    /**
     * Deal a card from the deck of cards
     * @return The next undealt card from the deck of cards
     */
    public Card deal() {
        numDealt += 1;
        return deck.get(numDealt - 1);
    }

    /**
     * Get the number of undealt cards from the deck of cards
     * @return The number of undealt cards from the deck of cards
     */
    public int size() {
        return 52 - numDealt;
    }

    /**
     * Determine if there's enough cards left to play a round
     * @return True if there's enough cards left to play a round. Otherwise, return false
     */
    public boolean enough() {
        if (this.size() >= 4) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Gather all the cards (dealt and undealt) and reshuffle the deck of cards
     */
    public void gather() {
        numDealt = 0;
        this.shuffle();
    }

    /**
     * Check whether if the deck is empty or not
     */
    public boolean isEmpty() {
        if (size() == 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Print out all the undealt cards from the deck of cards
     * @return The string of all the undealt cards from the deck of cards
     */
    public String toString() {
        String results = "";
        for (int c = numDealt; c < deck.size(); c++) {
            results += deck.get(c).toString() + "\n";
        }
        return results;
    }
}

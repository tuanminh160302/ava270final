package proj4;

public class DeckTesting {

    /**
     * Create a test case to test the size method of Deck class
     * @param msg The message describes the test case
     * @param numDeal The number of dealt cards
     * @param expected The expected result
     */
    public static void testDeckSize(String msg, int numDeal, int expected) {
        Testing ts = new Testing();
        ts.setVerbose(true);
        Deck deck = new Deck();
        for (int i = 0; i < numDeal; i ++) {
            deck.deal();
        }
        ts.assertEquals(msg, expected, deck.size());
    }

    /**
     * Create a test case to test the isEmpty method of Deck class
     * @param msg The message describes the test case
     * @param numDeal The number of dealt cards
     * @param expected The expected result
     */
    public static void testIsEmpty(String msg, int numDeal, boolean expected) {
        Testing ts = new Testing();
        ts.setVerbose(true);
        Deck deck = new Deck();
        for (int i = 0; i < numDeal; i ++) {
            deck.deal();
        }
        ts.assertEquals(msg, expected, deck.isEmpty());
    }

    public static void main(String[] args) {
        Testing ts = new Testing();
        ts.startTests();
        testDeckSize("Check the size of the deck after deal 5 cards", 5, 47);
        testDeckSize("Check the size of the deck after deal 52 cards", 52, 0);
        testIsEmpty("Check if deck is empty after deal 15 cards", 15, false);
        testIsEmpty("Check if deck is empty after deal 52 cards", 52, true);
        ts.finishTests();
    }
}

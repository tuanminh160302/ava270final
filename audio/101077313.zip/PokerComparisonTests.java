package proj4;

import java.util.ArrayList;

public class PokerComparisonTests {

    /**
     * Create a poker hand from a string represent a card list
     * @param cardListStr The string represent a card list
     * @return A poker hand
     */
    public static PokerHand createHand(String cardListStr) {
        ArrayList<Card> cardList = new ArrayList<>();
        String[] cards = cardListStr.split(" ");
        for (int i = 0; i < 5; i ++) {
            String card = cards[i];
            String rankStr = card.substring(0, card.length() - 1);
            String suit = card.substring(card.length() - 1);

            if (rankStr.equals("J")) {
                rankStr = "11";
            } else if (rankStr.equals("Q")) {
                rankStr = "12";
            } else if (rankStr.equals("K")) {
                rankStr = "13";
            } else if (rankStr.equals("A")) {
                rankStr = "14";
            }

            if (suit.equals("S")) {
                suit = "Spades";
            } else if (suit.equals("H")) {
                suit = "Hearts";
            } else if (suit.equals("D")) {
                suit = "Diamonds";
            } else if (suit.equals("C")) {
                suit = "Clubs";
            }

            Card c = new Card(rankStr, suit);
            cardList.add(c);
        }
        PokerHand hand = new PokerHand(cardList);
        return hand;
    }

    /**
     * Create a test case
     * @param cardListStr1 The string represent the first card list
     * @param cardListStr2 The string represent the second card list
     * @param msg The message for the test case
     * @param expected The expected result for the test case
     */
    public static void createTestCase(String cardListStr1, String cardListStr2, String msg, int expected) {
        PokerHand hand1 = createHand(cardListStr1);
        PokerHand hand2 = createHand(cardListStr2);
        Testing ts = new Testing();
        ts.setVerbose(true);
        ts.assertEquals(msg, expected, hand1.compareTo(hand2));
    }

    public static void main(String[] args) {
        Testing ts = new Testing();
        ts.startTests();

        createTestCase("9S 4D 9H 5C 4H", "9D KD QS JH 9C",
                "1-pair vs 2-pair (9s and 4s vs 9s)", 1);

        createTestCase("7H 9D 5C AH 5S", "4D 8D 9C QC KD",
                "1-pair (5s) vs high card (King high)", 1);

        createTestCase("AH 2D 3S AD 5C", "3D 4D 7D 8D 9D",
                "1-pair (As) vs flush (9 high)", -1);

        createTestCase("3D 8S 3H QC QD", "4D 7S 8D JS AC",
                "2-pair (3s and Queens) vs high card (Ace high)", 1);

        createTestCase("3D QS QH 5C 3C", "5D 7D 8D 10D JD",
                "2-pair (3s and Queens) vs flush (Jack high)", -1);

        createTestCase("2S 7S 8S JS KS", "3D 4S 5C QH AH",
                "flush (King high) vs high card (Ace high)", 1);

        createTestCase("9D 2S 3H 9H 9C", "4C 7C 9C QC KC",
                "3-of-a-kind (9s) vs flush (King high)", -1);

        createTestCase("KH 10H 2D 10C 10S", "4D 5S 3H 3S 4H",
                "3-of-a-kind (10s) vs 2-pair (3s and 4s)", -1);

        createTestCase("QC 9D JH 9H 9C", "10D 7H 6S 3D 2C",
                "3-of-a-kind (9s) vs high card (10 high)", 1);

        createTestCase("AS KD KC AH KH", "8C 2C QC 4C JC",
                "full house vs flush (Queen high)", -1);

        createTestCase("8S 10C 8D 10H 10S", "KC 7H 2H KD 5S",
                "full house vs 1 pair (Kings)", 1);

        createTestCase("QS JS JD QH JH", "9D 7S 2C 5H 8H",
                "full house vs high card (9 high)", 1);

        createTestCase("QD 9H QC QS QH", "2S KS JS 4S 3S",
                "4-of-a-kind (Queens) vs flush (King high)", -1);

        createTestCase("8D KS KC KD KH", "AS 2D 3H AC 5S",
                "4-of-a-kind (Kings) vs 1-pair (Aces)", 1);

        createTestCase("JD JS JH 4S JC", "4D 8S KH 7H 3C",
                "4-of-a-kind (Jacks) vs high card (King high)", 1);

        createTestCase("2S 10S 9S 8S KS", "3C 7C JC AC 2C",
                "two flushes - different on high card", -1);

        createTestCase("8H 9H 2H 7H KH", "KD 10D 2D 4D 5D",
                "two flushes - different on 2nd highest card", -1);

        createTestCase("10C AC KC 9C 2C", "7D 8D KD AD QD",
                "two flushes - different on 3rd highest card", -1);

        createTestCase("2S 3S KS 9S QS", "KH 9H 2H QH 5H",
                "two flushes - different on 4th highest card", -1);

        createTestCase("7D 9D 6D JD 10D", "JS 9S 7S 10S 5S",
                "two flushes - different on 5th highest card", 1);

        createTestCase("8C 10C 3C AC KC", "AS 10S 8S KS 3S",
                "two flushes - tied", 0);

        createTestCase("7S 9S 9D 3H 3D", "7D 6D 7H 4D 4C",
                "two 2-pairs - different on high pairs", 1);

        createTestCase("10C KS AC 10H KC", "KD 9H KH QD QC",
                "two 2-pairs - different on low pairs", -1);

        createTestCase("9D 10H 3D 10S 3H", "3C 10C 10D 3S AH",
                "two 2-pairs - all pairs equal, different on high card", -1);

        createTestCase("AS 9H 3S 9D AC", "KS 3H KD KC KH",
                "2-pair (Aces and 9s) vs 4-of-a-kind (Kings), different on high pair", 1);

        createTestCase("3D 9S 3H 7C 9C", "9H 5D 5H 9D 5S",
                "2-pair (9s and 3s) and full house (5s and 9s), different on low pair", -1);

        createTestCase("8D 2D QS QH 2C", "2S QC QD 2H 8S",
                "two 2-pairs, tied", 0);

        createTestCase("JS 8D 10H JC 9D", "8S KD QS QH JH",
                "two 1-pairs, different on pair (Jacks vs Queens)", -1);

        createTestCase("9D 3S 4H 4D AS", "4C 4S KH 2D QC",
                "two 1-pairs, pair equal, different on high card", 1);

        createTestCase("6S KH 5C 10D 6H", "6D 9C 6C KD 5H",
                "two 1-pairs, pair equal, different on 2nd highest card", 1);

        createTestCase("2D 10H 7D 2S KD", "KH 2C 2H 10C 9S",
                "two 1-pairs, pair equal, different on 3rd highest card", -1);

        createTestCase("5S 5D JC 5H KD", "6S 4H 8D 6C 5C",
                "1-pair (6s) vs three-of-a-kind (5s), different on pair", -1);

        createTestCase("KS 2D AS KC 10C", "10D 2H KD KH AC",
                "two 1-pairs, tied", 0);

        createTestCase("4H 6H 9C AC QS", "6S 8H 10H 2C KC",
                "two high-cards, different on high card", 1);

        createTestCase("9D 8H 2C AD QD", "AS 2D 7H KS QC",
                "two high-cards, different on 2nd highest card", -1);

        createTestCase("3D 4S 5C QH AH", "AC 6D QS 2S 4H",
                "two high-cards, different on 3rd highest card", -1);

        createTestCase("8D KS QS 10C 2S", "4D 10D 9C QC KD",
                "two high-cards, different on 4th highest card", -1);

        createTestCase("9D 7S 2C 5H 8H", "3D 8C 5S 9H 7H",
                "two high-cards, different on 5th highest card", -1);

        createTestCase("10D 7H 6S 3D 2C", "9S 10D JH QH KC",
                "high card vs straight, different on high card", -1);

        createTestCase("3D 4C 5S QD AH", "AS 4D 5H 3H QS",
                "two high-cards, tied", 0);

        ts.finishTests();
    }
}

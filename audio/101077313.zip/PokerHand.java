package proj4; // do not erase. Gradescope expects this.

import java.util.*;

public class PokerHand {
    private ArrayList<Card> hand = new ArrayList<>();
    private final int FLUSH = 3;
    private final int TWO_PAIRS = 2;
    private final int ONE_PAIRS = 1;
    private final int HIGH_CARDS = 0;

    /**
     * Construct a poker hand of 5 cards
     * @param cardList The list of 5 cards that will be used to create a hand
     */
    public PokerHand(ArrayList<Card> cardList) {
        ArrayList<Card> cardListCopied = cardList;
        for (int i = 0; i < cardListCopied.size(); i ++) {
            if (hand.size() < cardListCopied.size()) {
                this.addCard(cardListCopied.get(i));
            }
        }
    }

    /**
     * Add a card to the hand
     * @param card The card that will be added to the hand
     */
    public void addCard(Card card) {
        hand.add(card);
    }

    /**
     * Get the card at the indicated index
     * @param index The indicated index of the needed card
     * @return The card at the indicated index
     */
    public Card getIthCard(int index) {
        return hand.get(index);
    }

    /**
     * Check to see if the hand is a flush
     * @return True if the hand is a flush. Otherwise, return false
     */
    private boolean flushCheck() {
        ArrayList<String> suitList = new ArrayList<>();
        for (int i = 0; i < 5; i ++) {
            String suit = hand.get(i).getSuit();
            suitList.add(suit);
        }
        HashSet suitSet = new HashSet(suitList);
        return suitSet.size() == 1;
    }

    /**
     * Check to see if the hand is a 1-pair or 2-pair
     * @return 1 if the hand is a 1-pair and 2 if the hand is a 2-pair
     */
    private int pairCheck() {
        int pair = 0;
        ArrayList<Integer> cardRankList = new ArrayList<>();
        for (int i = 0; i < 5; i ++) {
            int rank = hand.get(i).getRank();
            cardRankList.add(rank);
        }
        Collections.sort(cardRankList);
        int index = 0;
        while (index < cardRankList.size() - 1) {
            if (cardRankList.get(index) == cardRankList.get(index + 1)) {
                pair += 1;
                index += 2;
            } else {
                index += 1;
            }
        }
        return pair;
    }

    /**
     * Check to see if the hand is a high cards
     * @return True if the hand is a high cards. Otherwise, return false
     */
    private boolean highCardsCheck() {
        boolean condition = !this.flushCheck() && this.pairCheck() == 0;
        return condition;
    }

    /**
     * Get the kind of a hand
     * @return the kind of a hand
     */
    private int checkHandKind() {
        int kind = -1;
        if (this.flushCheck()) {
            kind = this.FLUSH;
        } else if (this.pairCheck() == 2) {
            kind = this.TWO_PAIRS;
        } else if (this.pairCheck() == 1) {
            kind = this.ONE_PAIRS;
        } else if (this.highCardsCheck()) {
            kind = this.HIGH_CARDS;
        }
        return kind;
    }

    /**
     * Get the list of rank of all the cards in a hand
     * @return The list of rank of all the cards in a hand
     */
    private ArrayList<Integer> getRankList() {
        ArrayList<Integer> rankList = new ArrayList<>();
        for (int i = 0; i < 5; i ++) {
            rankList.add(hand.get(i).getRank());
        }
        return rankList;
    }

    /**
     * Get the sorted (high-low) list of rank of all the cards in a hand
     * @return The sorted (high-low) list of rank of all the cards in a hand
     */
    private ArrayList<Integer> getHandRanksSorted() {
        ArrayList<Integer> handRanksSorted = new ArrayList<>();
        handRanksSorted = this.getRankList();
        Collections.sort(handRanksSorted, Collections.reverseOrder());
        return handRanksSorted;
    }

    /**
     * Get the list of all the duplicate cards in a hand
     * @return The list of all the duplicate cards in a hand
     */
    private ArrayList<Integer> getDuplicatesCard() {
        ArrayList<Integer> duplicates = new ArrayList<>();
        ArrayList<Integer> cardRankList;
        cardRankList = this.getRankList();
        while (cardRankList.size() > 0) {
            int checkElt = cardRankList.get(0);
            cardRankList.remove(Integer.valueOf(checkElt));
            if (cardRankList.contains(checkElt)) {
                cardRankList.remove(Integer.valueOf(checkElt));
                duplicates.add(checkElt);
            }
        }
        return duplicates;
    }

    /**
     * Compare two 1-pair hands.
     * @param other The second hand
     * @return 1 if hand 1 > hand 2; -1 if hand 1 < hand 2; 0 if two hands are tied
     */
    private int compareSameOnePair(PokerHand other) {
        int pairValue1 = this.getDuplicatesCard().get(0);
        int pairValue2 = other.getDuplicatesCard().get(0);
        if (pairValue1 != pairValue2) {
            if (pairValue1 > pairValue2) {
                return 1;
            } else {
                return -1;
            }
        } else {
            ArrayList<Integer> cardRankList1 = this.getRankList();
            ArrayList<Integer> cardRankList2 = other.getRankList();
            Collections.sort(cardRankList1, Collections.reverseOrder());
            Collections.sort(cardRankList2, Collections.reverseOrder());
            for (int i = 0; i < 2; i ++) {
                cardRankList1.remove(Integer.valueOf(pairValue1));
                cardRankList2.remove(Integer.valueOf(pairValue2));
            }
            if (cardRankList1.equals(cardRankList2)) {
                return 0;
            } else {
                int highCard1 = cardRankList1.get(0);
                int highCard2 = cardRankList2.get(0);
                while (highCard1 == highCard2) {
                    cardRankList1.remove(Integer.valueOf(highCard1));
                    cardRankList2.remove(Integer.valueOf(highCard2));
                    highCard1 = cardRankList1.get(0);
                    highCard2 = cardRankList2.get(0);
                }
                if (highCard1 == highCard2) {
                    return 0;
                } else if (highCard1 > highCard2) {
                    return 1;
                } else {
                    return -1;
                }
            }
        }
    }

    /**
     * Compare two 2-pair hands
     * @param other The second hand
     * @return 1 if hand 1 > hand 2; -1 if hand 1 < hand 2; 0 if two hands are tied
     */
    private int compareSameTwoPair(PokerHand other) {
        ArrayList<Integer> pairValue1 = this.getDuplicatesCard();
        ArrayList<Integer> pairValue2 = other.getDuplicatesCard();
        Collections.sort(pairValue1, Collections.reverseOrder());
        Collections.sort(pairValue2, Collections.reverseOrder());
        if (pairValue1.get(0) > pairValue2.get(0)) {
            return 1;
        } else if (pairValue1.get(0) < pairValue2.get(0)) {
            return -1;
        } else {
            if (pairValue1.get(1) > pairValue2.get(1)) {
                return 1;
            } else if (pairValue1.get(1) < pairValue2.get(1)) {
                return -1;
            } else {
                ArrayList<Integer> cardRankList1 = this.getRankList();
                ArrayList<Integer> cardRankList2 = other.getRankList();
                for (int i = 0; i < 2; i ++) {
                    for (int k = 0; k < 2; k ++) {
                        cardRankList1.remove(Integer.valueOf(pairValue1.get(i)));
                        cardRankList2.remove(Integer.valueOf(pairValue2.get(i)));
                    }
                }
                if (cardRankList1.get(0) > cardRankList2.get(0)) {
                    return 1;
                } else if (cardRankList1.get(0) < cardRankList2.get(0)) {
                    return -1;
                } else {
                    return 0;
                }
            }
        }
    }

    /**
     * Compare two flush hands or two high-cards hands
     * @param other The second hand
     * @return 1 if hand 1 > hand 2; -1 if hand 1 < hand 2; 0 if two hands are tied
     */
    private int compareSameFlushHigh(PokerHand other) {
        ArrayList<Integer> handRanksSorted1 = this.getHandRanksSorted();
        ArrayList<Integer> handRanksSorted2 = other.getHandRanksSorted();
        int highCard1 = handRanksSorted1.get(0);
        int highCard2 = handRanksSorted2.get(0);
        while (highCard1 == highCard2 && handRanksSorted1.size() > 1) {
            handRanksSorted1.remove(0);
            handRanksSorted2.remove(0);
            highCard1 = handRanksSorted1.get(0);
            highCard2 = handRanksSorted2.get(0);
        }
        if (highCard1 > highCard2) {
            return 1;
        } else if (highCard1 == highCard2) {
            return 0;
        } else {
            return -1;
        }
    }

    /**
     * Get a list contains the hand kind of 2 poker hands
     * @param other The second hand
     * @return A list contains the hand kind of 2 poker hands
     */
    private ArrayList<Integer> getKindList(PokerHand other) {
        ArrayList<Integer> kindList = new ArrayList<>();
        kindList.add(this.checkHandKind());
        kindList.add(other.checkHandKind());
        return kindList;
    }

    /**
     * Compare two hands if they have different hand kinds
     * @param other The second hand
     * @return 1 if hand 1 > hand 2; -1 if hand 1 < hand 2; 0 if two hands are tied
     */
    private int compareDiffHandKind(PokerHand other) {
        if (this.checkHandKind() > other.checkHandKind()) {
            return 1;
        } else if (this.checkHandKind() < other.checkHandKind()) {
            return -1;
        } else {
            return 0;
        }
    }

    /**
     * Compare two hands if they have same hand kinds
     * @param other The second hand
     * @return 1 if hand 1 > hand 2; -1 if hand 1 < hand 2; 0 if two hands are tied
     */
    private int compareSameHandKind(PokerHand other) {
        if (this.checkHandKind() == this.FLUSH || this.checkHandKind() == this.HIGH_CARDS) {
            return this.compareSameFlushHigh(other);
        } else if (this.checkHandKind() == this.TWO_PAIRS) {
            return this.compareSameTwoPair(other);
        } else if (this.checkHandKind() == this.ONE_PAIRS) {
            return this.compareSameOnePair(other);
        } else {
            return 2;
        }
    }

    /**
     * Compare two poker hands
     * @param other The second hand
     * @return 1 if hand 1 > hand 2; -1 if hand 1 < hand 2; 0 if two hands are tied
     */
    public int compareTo(PokerHand other) {
        ArrayList<Integer> kindList = this.getKindList(other);
        HashSet kindSet = new HashSet(kindList);
        if (kindSet.size() == 1) {
            return this.compareSameHandKind(other);
        } else {
            return this.compareDiffHandKind(other);
        }
    }

    /**
     * Print out the poker hand
     * @return The string version of the poker hand
     */
    public String toString() {
        String results = "Poker hand: \n";
        for (int i = 0; i < 5; i ++) {
            results += hand.get(i).toString() + "\n";
        }
        return results;
    }
}

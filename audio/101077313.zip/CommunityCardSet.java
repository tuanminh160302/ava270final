package proj4;
import java.util.*;

public class CommunityCardSet {
    ArrayList<Card> communityCards = new ArrayList<>();;

    /**
     * Construct a community card set
     * @param cardList A cardlist that contains 5 cards
     */
    public CommunityCardSet(ArrayList<Card> cardList) {
        ArrayList<Card> cardListCopied = cardList;
        for (int i = 0; i < cardListCopied.size(); i ++) {
            if (communityCards.size() < cardListCopied.size()) {
                this.addCard(cardListCopied.get(i));
            }
        }
    }

    /**
     * Add a card to the community card set
     * @param card A card
     */
    public void addCard(Card card) {
        communityCards.add(card);
    }

    /**
     * Get a card given the wanted index
     * @param index The index of the wanted card
     * @return the card at the wanted index
     */
    public Card getIthCard(int index) {
        return communityCards.get(index);
    }

    /**
     * Print out the community card set
     * @return The string of all the cards in the community card set
     */
    public String toString() {
        String results = "The community cards are: \n";
        int slashCounter = 4;
        for (int i = 0; i < communityCards.size(); i ++) {
            String cardToString = communityCards.get(i).toString();
            results = results + cardToString;
            if (slashCounter != 0) {
                results += "  |  ";
                slashCounter -= 1;
            }
        }
        results += "\n";
        return results;
    }
}

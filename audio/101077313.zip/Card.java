package proj4; // do not erase. Gradescope expects this.

import java.util.ArrayList;
import java.util.Arrays;

public class Card {
    private int rank;
    private String suit;

    /**
     * Creates a Card with a given rank and suit.
     *
     * @param rank whole cards (2-10) can either be spelled
     *              out like "two" or numeric like "2". Case
     *              insensitive.
     * @param suit "Spades", "Hearts", "Clubs", or "Diamonds"
     */
    public Card(String rank, String suit) {
        this.suit = suit;
        ArrayList<String> rankStringList = new ArrayList<>(Arrays.asList("two", "three", "four", "five",
                "six", "seven", "eight", "nine", "ten", "jack", "queen", "king", "ace"));
        ArrayList<String> rankNumericStringList = new ArrayList<>(Arrays.asList("2", "3", "4", "5", "6", "7", "8", "9",
                "10", "11", "12", "13", "14"));
        ArrayList<Integer> rankIntList = new ArrayList<>(Arrays.asList(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14));
        rank = rank.toLowerCase();
        for (int i = 0; i < 13; i++) {
            if (rank.equals(rankStringList.get(i))) {
                int rankInt = rankIntList.get(i);
                this.rank = rankInt;
            } else if (rank.equals(rankNumericStringList.get(i))) {
                int rankInt = rankIntList.get(i);
                this.rank = rankInt;
            }
        }
    }

    /**
     * Creates a Card with a given rank and suit.
     *
     * @param rank The rank of the card, which must be between
     *              2 and 14, inclusive.
     * @param suit The suit of the card, which must be
     *              0=SPADES, 1=HEARTS, 2=CLUBS, or 3=DIAMONDS
     */
    public Card(int rank, int suit) {
        this.rank = rank;
        ArrayList<Integer> suitIntList = new ArrayList<>(Arrays.asList(0, 1, 2, 3));
        ArrayList<String> suitStringList = new ArrayList<>(Arrays.asList("Spades", "Hearts", "Clubs", "Diamonds"));
        for (int i = 0; i < 4; i++) {
            if (suit == suitIntList.get(i)) {
                String suitString = suitStringList.get(i);
                this.suit = suitString;
            }
        }
    }

    /**
     * Get the rank of the card
     * @return The rank of the card
     */
    public int getRank() {
        return this.rank;
    }

    /**
     * Get the suit of the card
     * @return The suit of the card
     */
    public String getSuit() {
        return this.suit;
    }

    /**
     * Get the rank of the card as a string
     * @return The string version of the rank of the card
     */
    private String getRankString() {
        String rankString = String.valueOf(this.rank);
        if (rankString.equals("11")) {
            rankString = "Jack";
        } else if (rankString.equals("12")) {
            rankString = "Queen";
        } else if (rankString.equals("13")) {
            rankString = "King";
        } else if (rankString.equals("14")) {
            rankString = "Ace";
        }

        return rankString;
    }

    /**
     * Print out the card
     * @return The formatted string of the card
     */
    public String toString() {
        return String.format("%s of %s", getRankString(), getSuit());
    }
}
